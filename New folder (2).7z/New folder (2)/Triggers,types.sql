--------------------------------------------------------
--  File created - Tuesday-July-11-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type GEN_STR_TBL
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."GEN_STR_TBL" IS TABLE OF VARCHAR2(32767); 

/
-- Unable to render TYPE DDL for object HMCORE.SYS_PLSQL_101852_155_1 with DBMS_METADATA attempting internal generator.
CREATE TYPE          SYS_PLSQL_101852_155_1 as object (PN01 VARCHAR2(4000 BYTE),
PN02 VARCHAR2(4000 BYTE),
PN03 VARCHAR2(4000 BYTE),
PN04 VARCHAR2(4000 BYTE),
PN05 VARCHAR2(4000 BYTE),
PN07 VARCHAR2(4000 BYTE),
PN08 VARCHAR2(4000 BYTE),
PN09 VARCHAR2(4000 BYTE),
PN10 VARCHAR2(4000 BYTE),
PN11 VARCHAR2(4000 BYTE),
PN12 VARCHAR2(4000 BYTE),
PN13 VARCHAR2(4000 BYTE),
PA01 VARCHAR2(4000 BYTE),
PA02 VARCHAR2(4000 BYTE),
PA03 VARCHAR2(4000 BYTE),
PA04 VARCHAR2(4000 BYTE),
PA05 VARCHAR2(4000 BYTE),
PA06 VARCHAR2(4000 BYTE),
PA07 VARCHAR2(4000 BYTE),
PI01 VARCHAR2(4000 BYTE),
CUST_ID NUMBER,
APP_ID NUMBER,
MEM_REF_NO VARCHAR2(25 BYTE),
MEM_CODE VARCHAR2(10 BYTE),
INQ_PASSWORD VARCHAR2(5 BYTE),
INQ_PURPOSE NUMBER,
INQ_AMT NUMBER);
-- Unable to render TYPE DDL for object HMCORE.SYS_PLSQL_101852_339_1 with DBMS_METADATA attempting internal generator.
CREATE TYPE          SYS_PLSQL_101852_339_1 as table of "HMCORE"."SYS_PLSQL_101852_155_1";
-- Unable to render TYPE DDL for object HMCORE.SYS_PLSQL_101852_DUMMY_1 with DBMS_METADATA attempting internal generator.
CREATE TYPE          SYS_PLSQL_101852_DUMMY_1 as table of number;
--------------------------------------------------------
--  DDL for Type TYP_KEY_VAL
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_KEY_VAL" AS TABLE OF VARCHAR2(500); 

/
--------------------------------------------------------
--  DDL for Type TYP_NAME_COLL
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_NAME_COLL" is table of TYP_NAME_OBJ ; 

/
--------------------------------------------------------
--  DDL for Type TYP_NAME_OBJ
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_NAME_OBJ" as object 
(PARSE_KEY VARCHAR2(4000),PARSE_VALUE VARCHAR2(4000)); 

/
--------------------------------------------------------
--  DDL for Type TYP_PKG_INQ_CANDIDATES
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_PKG_INQ_CANDIDATES" AS TABLE OF VARCHAR2(4000); 

/
--------------------------------------------------------
--  DDL for Trigger TR_TRANSFORMATION_TRKG
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "HMCORE"."TR_TRANSFORMATION_TRKG" 
AFTER INSERT OR UPDATE ON HMCORE.CHM_TRANSFORMATION_CATALOGUE
   FOR EACH ROW
    WHEN (
        (NEW.TARGET_VALUE <> OLD.TARGET_VALUE ) OR (NEW.TARGET_VALUE IS NOT NULL AND OLD.TARGET_VALUE IS NULL)         
        OR
        (NEW.STATUS <> OLD.STATUS ) OR (NEW.STATUS IS NOT NULL AND OLD.STATUS IS NULL)         
       ) DECLARE

  PRAGMA AUTONOMOUS_TRANSACTION;
  
  ln_cnt NUMBER;  
  
  EX_RAISE EXCEPTION;
  
  LV_SWAP VARCHAR2(32767);
  LV_SWAP1 VARCHAR2(32767);
  LV_SWAP2 VARCHAR2(32767);
  
BEGIN  
  
      BEGIN
        
          /* LV_SWAP := 'SELECT COUNT( DISTINCT FORMAT ) CNT            
            FROM (
                 SELECT FORMAT FORMAT
                 FROM 
                 (
                  SELECT CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(m|M)]{2}(.)*[(y|Y|r|R)]{2,4}'') 
                         THEN ''DMY'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(mon|MON)]{2}(.)*[(y|Y|r|R)]{2,4}'') 
                         THEN  ''DMY'' 
                         ELSE  NULL END DMY,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(m|M)]{2}(.)*[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}'')
                         THEN ''MDY'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(mon|MON)]{2}(.)*[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}'')
                         THEN ''MDY''
                         ELSE  NULL END MDY,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(m|M)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}'')
                         THEN ''MYD'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(mon|MON)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}'')
                         THEN ''MYD''
                         ELSE  NULL END MYD,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(m|M)]{2}(.)*[(d|D)]{2}'')
                         THEN ''YMD'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(mon|MON)]{2}(.)*[(d|D)]{2}'')
                         THEN ''YMD''  
                         ELSE  NULL END YMD,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}(.)*[(m|M)]{2}'')
                         THEN ''YDM'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}(.)*[(mon|MON)]{2}'')
                         THEN ''YDM''  
                         ELSE  NULL END YDM,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(m|M)]{2}'')
                         THEN ''DYM'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(mon|MON)]{2}'')
                         THEN ''DYM''  
                         ELSE  NULL END DYM,
                         TARGET_VALUE
                    FROM (
                    ';
                    
                    LV_SWAP1 := '      
                    SELECT TARGET_VALUE
                            FROM (
                                    SELECT SUBSTR(TARGET_VALUE,INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)+1,DECODE (INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL),NULL, LENGTH(TARGET_VALUE),   INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)-1) ) TARGET_VALUE
                                      FROM ( 
                                                SELECT ''|''||TARGET_VALUE||''|'' TARGET_VALUE, FIELD_ID , DATA_MAPPING_ID, MFI_ID 
                                                  FROM HMCORE.CHM_TRANSFORMATION_CATALOGUE
                                                 WHERE FIELD_ID = '||:NEW.FIELD_ID ||'
                                                   AND DATA_MAPPING_ID = '||:NEW.DATA_MAPPING_ID||'
                                                   AND MFI_ID = '''||:NEW.MFI_ID||'''
                                                   AND STATUS = 1
                                                 UNION
                                                SELECT ''|''||'''||:NEW.TARGET_VALUE||'''||''|'' TARGET_VALUE, '||:NEW.FIELD_ID||', '||:NEW.DATA_MAPPING_ID ||', '''||:NEW.MFI_ID ||'''
                                                  FROM DUAL
                                            ), 
                                            (
                                               SELECT LEVEL LEVL FROM DUAL CONNECT BY LEVEL <= 20
                                            ) TEMP
                                 )
                           WHERE TARGET_VALUE IS NOT NULL
                           UNION
                          SELECT TARGET_VALUE
                            FROM (
                            
                            ';
                            
                            LV_SWAP2 :=  '   
                            SELECT SUBSTR(TARGET_VALUE,INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)+1,DECODE (INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL),NULL, LENGTH(TARGET_VALUE),   INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)-1) ) TARGET_VALUE
                                      FROM ( 
                                                SELECT ''|''||TARGET_VALUE||''|'' TARGET_VALUE, FIELD_ID , DATA_MAPPING_ID, MFI_ID 
                                                  FROM HMCORE.CHM_TRANSFORMATION_CATALOGUE
                                                 WHERE FIELD_ID = '||NVL(:OLD.FIELD_ID,0)||'
                                                   AND DATA_MAPPING_ID = '||NVL(:OLD.DATA_MAPPING_ID,0)||'
                                                   AND MFI_ID = '''|| NVL(:OLD.MFI_ID,'0')||'''
                                                   AND STATUS = 1
                                                    UNION
                                                SELECT ''|''||'''||NVL(:OLD.TARGET_VALUE,0)||'''||''|'' TARGET_VALUE, '||NVL(:OLD.FIELD_ID,0)||', '||NVL(:OLD.DATA_MAPPING_ID,0 )||', '''||NVL(:OLD.MFI_ID,0) ||'''
                                                  FROM DUAL
                                            ), 
                                            (
                                               SELECT LEVEL LEVL FROM DUAL CONNECT BY LEVEL <= 20
                                            ) TEMP
                                 )
                           WHERE TARGET_VALUE IS NOT NULL  
                          )
                  )
                  UNPIVOT
                  (   
                     FORMAT FOR FORMATn IN (DMY,MDY,MYD,YMD,YDM,DYM)    
                  )
                  )
                  
                  ';*/
                  
                /*PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','LV_SWAP  '|| LV_SWAP );  
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','LV_SWAP1  '|| LV_SWAP1 );  
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','LV_SWAP2  '|| LV_SWAP2 );  
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':NEW.FIELD_ID  '|| :NEW.FIELD_ID );
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':NEW.DATA_MAPPING_ID '||:NEW.DATA_MAPPING_ID);
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':NEW.MFI_ID '||:NEW.MFI_ID);
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':NEW.STATUS '||:NEW.STATUS);
                
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':OLD.FIELD_ID  '|| :OLD.FIELD_ID );
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':OLD.DATA_MAPPING_ID '||:OLD.DATA_MAPPING_ID);
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':OLD.MFI_ID '||:OLD.MFI_ID);
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',':OLD.STATUS '||:OLD.STATUS);
                
                PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','ln_cnt '||ln_cnt);
              */  
                  
                  
           EXECUTE IMMEDIATE      
           'SELECT COUNT( DISTINCT FORMAT ) CNT            
            FROM (
                 SELECT FORMAT FORMAT
                 FROM 
                 (
                  SELECT CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(m|M)]{2}(.)*[(y|Y|r|R)]{2,4}'') 
                         THEN ''DMY'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(mon|MON)]{2}(.)*[(y|Y|r|R)]{2,4}'') 
                         THEN  ''DMY'' 
                         ELSE  NULL END DMY,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(m|M)]{2}(.)*[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}'')
                         THEN ''MDY'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(mon|MON)]{2}(.)*[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}'')
                         THEN ''MDY''
                         ELSE  NULL END MDY,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(m|M)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}'')
                         THEN ''MYD'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(mon|MON)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}'')
                         THEN ''MYD''
                         ELSE  NULL END MYD,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(m|M)]{2}(.)*[(d|D)]{2}'')
                         THEN ''YMD'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(mon|MON)]{2}(.)*[(d|D)]{2}'')
                         THEN ''YMD''  
                         ELSE  NULL END YMD,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}(.)*[(m|M)]{2}'')
                         THEN ''YDM'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(y|Y|r|R)]{2,4}(.)*[(d|D)]{2}(.)*[(mon|MON)]{2}'')
                         THEN ''YDM''  
                         ELSE  NULL END YDM,
                         CASE WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(m|M)]{2}'')
                         THEN ''DYM'' 
                         WHEN  REGEXP_LIKE(TARGET_VALUE,''[(d|D)]{2}(.)*[(y|Y|r|R)]{2,4}(.)*[(mon|MON)]{2}'')
                         THEN ''DYM''  
                         ELSE  NULL END DYM,
                         TARGET_VALUE
                    FROM (
                          SELECT TARGET_VALUE
                            FROM (
                                    SELECT SUBSTR(TARGET_VALUE,INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)+1,DECODE (INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL),NULL, LENGTH(TARGET_VALUE),   INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)-1) ) TARGET_VALUE
                                      FROM ( 
                                                SELECT ''|''||TARGET_VALUE||''|'' TARGET_VALUE, FIELD_ID , DATA_MAPPING_ID, MFI_ID 
                                                  FROM HMCORE.CHM_TRANSFORMATION_CATALOGUE
                                                 WHERE FIELD_ID = '||:NEW.FIELD_ID ||'
                                                   AND DATA_MAPPING_ID = '||:NEW.DATA_MAPPING_ID||'
                                                   AND MFI_ID = '''||:NEW.MFI_ID||'''
                                                   AND STATUS = 1
                                                 UNION
                                                SELECT ''|''||'''||:NEW.TARGET_VALUE||'''||''|'' TARGET_VALUE, '||:NEW.FIELD_ID||', '||:NEW.DATA_MAPPING_ID ||', '''||:NEW.MFI_ID ||'''
                                                  FROM DUAL
                                            ), 
                                            (
                                               SELECT LEVEL LEVL FROM DUAL CONNECT BY LEVEL <= 20
                                            ) TEMP
                                 )
                           WHERE TARGET_VALUE IS NOT NULL
                           UNION
                          SELECT TARGET_VALUE
                            FROM (
                                    SELECT SUBSTR(TARGET_VALUE,INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)+1,DECODE (INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL),NULL, LENGTH(TARGET_VALUE),   INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL+1)-INSTR(TARGET_VALUE,''|'',1,TEMP.LEVL)-1) ) TARGET_VALUE
                                      FROM ( 
                                                SELECT ''|''||TARGET_VALUE||''|'' TARGET_VALUE, FIELD_ID , DATA_MAPPING_ID, MFI_ID 
                                                  FROM HMCORE.CHM_TRANSFORMATION_CATALOGUE
                                                 WHERE FIELD_ID = '||NVL(:OLD.FIELD_ID,0)||'
                                                   AND DATA_MAPPING_ID = '||NVL(:OLD.DATA_MAPPING_ID,0)||'
                                                   AND MFI_ID = '''|| NVL(:OLD.MFI_ID,'0')||'''
                                                   AND STATUS = 1
                                                 UNION
                                                SELECT ''|''||'''||NVL(:OLD.TARGET_VALUE,0)||'''||''|'' TARGET_VALUE, '||NVL(:OLD.FIELD_ID,0)||', '||NVL(:OLD.DATA_MAPPING_ID,0 )||', '''||NVL(:OLD.MFI_ID,0) ||'''
                                                  FROM DUAL
                                            ), 
                                            (
                                               SELECT LEVEL LEVL FROM DUAL CONNECT BY LEVEL <= 20
                                            ) TEMP
                                 )
                           WHERE TARGET_VALUE IS NOT NULL  
                          )
                  )
                  UNPIVOT
                  (   
                     FORMAT FOR FORMATn IN (DMY,MDY,MYD,YMD,YDM,DYM)    
                  )
                  )'
                  INTO  ln_cnt;
                  
                  
                  
                
                
       EXCEPTION
       WHEN NO_DATA_FOUND
       THEN 
            ln_cnt := 0;
            
            --PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','NO_DATA COMMIT');
            
       END ; 
           
           IF ln_cnt > 1 
           THEN 

             --PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','ROLLBACK');
             
             RAISE EX_RAISE;
                      
           
           ELSE              
              -- COMMIT;
               --PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','COMMIT');           
               
               IF    :NEW.TARGET_VALUE IS NOT NULL AND :OLD.TARGET_VALUE IS NULL
               THEN 
               
                    /* INSERT INTO HMCORE.CHM_TRANSFORMATION_CATALOGUE
                     (
                            MFI_ID ,
                            ID_NUM ,
                            FIELD_ID ,
                            DATA_MAPPING_ID ,
                            SEGMENT_ID ,
                            TARGET_VALUE,
                            STATUS
                     )
                     VALUES
                     (
                            :NEW.MFI_ID,                      
                             HMRACPROD.SQ_TRANSFORMATION_CAT_ID_NUM.NEXTVAL,
                            :NEW.FIELD_ID ,
                            :NEW.DATA_MAPPING_ID ,
                            :NEW.SEGMENT_ID ,
                            :NEW.TARGET_VALUE,
                            1
                     );*/
               
                    -- PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',' insert COMMIT');           
                     COMMIT;
                     
               
               ELSIF ( :NEW.TARGET_VALUE <> :OLD.TARGET_VALUE ) AND ( :NEW.TARGET_VALUE IS NOT NULL AND  :OLD.TARGET_VALUE IS NOT NULL )
               THEN 
                 
                   /*UPDATE HMCORE.CHM_TRANSFORMATION_CATALOGUE
                      SET TARGET_VALUE     = :NEW.TARGET_VALUE                     
                    WHERE MFI_ID           = :OLD.MFI_ID 
                      AND FIELD_ID         = :OLD.FIELD_ID 
                      AND DATA_MAPPING_ID  = :OLD.DATA_MAPPING_ID 
                      AND SEGMENT_ID       = :OLD.SEGMENT_ID 
                      AND TARGET_VALUE     = :OLD.TARGET_VALUE;
                   */ 
                    
                    COMMIT;
                    
                   -- PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',' updt COMMIT');           
               
               
               END IF;
               
               -- PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','EN DIF');           
                                                               
           END IF;
                  
           --PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','COMPLETE');           

EXCEPTION
WHEN EX_RAISE
THEN 
     ROLLBACK;
     
     --PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG','ERROR IS '||SQLERRM);
     RAISE;
  
WHEN OTHERS
THEN 
     ROLLBACK;
    -- PK_UTILITIES_4.PR_LOG_FILE_MANAGE('A','MFI_HC','TRIGGER_TEST_SWAP.LOG',' ERR '||SQLERRM);  
     RAISE;
     
END;
        
              
  


/
ALTER TRIGGER "HMCORE"."TR_TRANSFORMATION_TRKG" ENABLE;
