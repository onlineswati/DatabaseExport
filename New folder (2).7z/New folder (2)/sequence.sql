--------------------------------------------------------
--  File created - Tuesday-July-11-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence AUDIT_MASTER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."AUDIT_MASTER_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999 INCREMENT BY 1 START WITH 67 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence B2CPRICE_PROD_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."B2CPRICE_PROD_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 7 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence B2C_TICKET_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."B2C_TICKET_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 42 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence BILLING_STATUS_TRKG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."BILLING_STATUS_TRKG_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 861 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CHM_BBC_MERCHANT_ACCESS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CHM_BBC_MERCHANT_ACCESS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CHM_INQ_BATCH_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CHM_INQ_BATCH_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CHM_VERIFICATION_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CHM_VERIFICATION_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CHM_VER_STS_TRACKING_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CHM_VER_STS_TRACKING_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 49643 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CMT_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CMT_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 19537 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CNS_DUMP_TBL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CNS_DUMP_TBL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 2562 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_DUP_BATCH_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_DUP_BATCH_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 151 CACHE 50 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_IOI_STD_ADR_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_IOI_STD_ADR_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 75001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_IOI_STD_CNS_CNS_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_IOI_STD_CNS_CNS_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 58361 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_IOI_STD_PHN_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_IOI_STD_PHN_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 78001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_LTC_FULL_PHONE_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_LTC_FULL_PHONE_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_LTC_ID_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_LTC_ID_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 25001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_LTC_NAME_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_LTC_NAME_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 22001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_LTC_PHONE_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_LTC_PHONE_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 18001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_LTC_SCL_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_LTC_SCL_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 19001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_LTC_SC_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_LTC_SC_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 3001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence COMM_LTC_SP_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."COMM_LTC_SP_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 7001 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CUST_PROD_OPTION_RULE_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CUST_PROD_OPTION_RULE_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 47 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence CUST_PRO_OPT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."CUST_PRO_OPT_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 400037 CACHE 20000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence DISCOUNT_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."DISCOUNT_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 59 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence DISCOUNT_MASTER_AUD_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."DISCOUNT_MASTER_AUD_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 23 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ERROR_TRACK_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ERROR_TRACK_SEQUENCE"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 5537859 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ES_IDS_ADR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ES_IDS_ADR_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ES_IDS_CNS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ES_IDS_CNS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ES_IDS_CP_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ES_IDS_CP_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ES_IDS_PHN_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ES_IDS_PHN_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ES_IDS_REL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ES_IDS_REL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ES_IDS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ES_IDS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence FILE_TRACK_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."FILE_TRACK_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 51235087 CACHE 5000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_BATCH
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_BATCH"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 52967951 CACHE 5000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_BILLING_INVOICE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_BILLING_INVOICE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8431 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CNTRBTR_SBMTR_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CNTRBTR_SBMTR_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CNTRIBTOR_FL_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CNTRIBTOR_FL_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CONSORTIUM_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CONSORTIUM_AUDIT_LOG_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 7541 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CONSORT_CONSORTIUM_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CONSORT_CONSORTIUM_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 8003 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CONSORT_CON_COR_LINK_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CONSORT_CON_COR_LINK_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 10503 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CONTRIBUTION_SBMTER_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CONTRIBUTION_SBMTER_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 161277 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CONTRIBUTOR_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CONTRIBUTOR_AUDIT_LOG_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 121605 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CONTRIBUTOR_FILE_CODE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CONTRIBUTOR_FILE_CODE_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 157146 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CONTRIBUTOR_ID_SEQNO
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CONTRIBUTOR_ID_SEQNO"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CORPORATE_CORPORATE_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CORPORATE_CORPORATE_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 116487 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CORP_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CORP_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 159086 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CPU_CPU_INQ_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CPU_CPU_INQ_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 27040897 CACHE 5000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CPU_CPU_REQ_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CPU_CPU_REQ_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 453599 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CUSTOMER_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CUSTOMER_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 30084 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CUSTOMER_ID_SEQNO
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CUSTOMER_ID_SEQNO"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 79 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CUSTOMER_USER_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CUSTOMER_USER_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 158126 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CUST_PRD_OPT_RUL_ADT_LG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CUST_PRD_OPT_RUL_ADT_LG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2001 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CUST_PROD_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CUST_PROD_AUDIT_LOG_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 77096 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_CUST_PROD_OPT_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_CUST_PROD_OPT_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2501 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_DAILY_BIL_INQ_INS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_DAILY_BIL_INQ_INS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_EMPLOYEE_EMP_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_EMPLOYEE_EMP_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 601 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_GROUP_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_GROUP_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 132 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_INQ_COM_RELATION_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_INQ_COM_RELATION_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 301 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_INQ_CONFIG_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_INQ_CONFIG_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 73 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_INQ_SKIP_ALERT_R01_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_INQ_SKIP_ALERT_R01_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 334 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_INQ_UNQ_REF_NO_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_INQ_UNQ_REF_NO_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 2683501 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_IOI_COMM_BATCH_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_IOI_COMM_BATCH_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 11 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_IOI_LTC_BATCH_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_IOI_LTC_BATCH_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 7266 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_LTC_IOI_LTC_BATCH_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_LTC_IOI_LTC_BATCH_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_MMS_EXT_USERS_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_MMS_EXT_USERS_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 5010 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_MMS_USER_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_MMS_USER_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3074 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_OPTIONS_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_OPTIONS_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1001 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_OPTIONS_DTL_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_OPTIONS_DTL_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1501 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_P99_BATCH_ID_R01_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_P99_BATCH_ID_R01_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1007 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_P99_BATCH_ID_R02_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_P99_BATCH_ID_R02_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 193130849 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_P99_BATCH_ID_R03_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_P99_BATCH_ID_R03_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8286 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_P99_BATCH_ID_R09_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_P99_BATCH_ID_R09_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_P99_BATCH_ID_R10_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_P99_BATCH_ID_R10_SEQ"  MINVALUE 80000 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 80160 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_PATH_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_PATH_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 23834 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_PORTFOLIO_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_PORTFOLIO_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 326743 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_PREF_DETAIL_PREFKEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_PREF_DETAIL_PREFKEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 3143 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_PREF_IDS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_PREF_IDS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 364 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_PRODUCTS_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_PRODUCTS_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1501 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_PRODUCTS_DTL_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_PRODUCTS_DTL_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 4001 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_PRODUCT_OPTNS_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_PRODUCT_OPTNS_AUDIT_LOG_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 91 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RECIPROCITY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RECIPROCITY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1361 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RECIPRO_PREF_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RECIPRO_PREF_AUDIT_LOG_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 7521 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RECIPRO_RCP_PREF_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RECIPRO_RCP_PREF_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 6503 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RECONCILATION_TRKG_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RECONCILATION_TRKG_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RECON_WEEKLY_TRKG_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RECON_WEEKLY_TRKG_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_REVIEW_ALLOCATION_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_REVIEW_ALLOCATION_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 1071048 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RULE_GROUP_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RULE_GROUP_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1501 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RULE_GRP_IVOL_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RULE_GRP_IVOL_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 6001 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_RULE_MASTER_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_RULE_MASTER_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2001 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SBDRY_DTLS_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SBDRY_DTLS_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 5515 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SBDRY_DTLS_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SBDRY_DTLS_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 111972 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SCHEDULER_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SCHEDULER_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SCHEDULE_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SCHEDULE_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 162636 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SUPER_USER_MAPPING_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SUPER_USER_MAPPING_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 4001 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SUPER_USER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SUPER_USER_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 4001 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SYSTEM_HM_SYS_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SYSTEM_HM_SYS_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 333860 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SYSTEM_USERS_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SYSTEM_USERS_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 111625 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_SYS_USR_ROLE_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_SYS_USR_ROLE_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 93179 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_UNQ_REF_NUM_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_UNQ_REF_NUM_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_UNRESOL_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_UNRESOL_KEY_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 44264 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USERGRP_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USERGRP_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 7 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USERGRP_PRODUCT_PREF_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USERGRP_PRODUCT_PREF_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 81041 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USERS_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USERS_AUDIT_LOG_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 327332 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USERS_USER_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USERS_USER_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 415870 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USER_GRP_USERGP_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USER_GRP_USERGP_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 80558 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USER_GRP_USERGRP_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USER_GRP_USERGRP_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1508 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USER_INVL_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USER_INVL_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 332674 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USER_INVOLVMT_AUDIT_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USER_INVOLVMT_AUDIT_LOG_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1539 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USER_SYS_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USER_SYS_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 22 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence HM_USER_USERGRP_AUDIT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."HM_USER_USERGRP_AUDIT_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 11990 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ID_INCREMENT
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."ID_INCREMENT"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 32092473 CACHE 2000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_ADDRESS_MATCH_KEYS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_ADDRESS_MATCH_KEYS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 345509891 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_CNS_DBLMETA_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_CNS_DBLMETA_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 297796529 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_CNS_HOMOPHONE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_CNS_HOMOPHONE_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 297728844 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_CNS_SOUNDEX_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_CNS_SOUNDEX_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 297733751 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_DOB_MATCH_KEYS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_DOB_MATCH_KEYS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 155808550 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_ID_MATCH_KEYS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_ID_MATCH_KEYS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 272248625 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_MATCH_CORRECTION_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_MATCH_CORRECTION_SEQ"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1950050 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_MATCH_INVOL_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_MATCH_INVOL_SEQUENCE"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 742123158 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_PHONE_MATCH_KEYS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_PHONE_MATCH_KEYS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 109429622 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_REL_DBLMETA_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_REL_DBLMETA_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 318198679 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_REL_HOMOPHONE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_REL_HOMOPHONE_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 318239837 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_REL_SOUNDEX_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_REL_SOUNDEX_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 318191169 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_SCL_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_SCL_KEY_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 463039085 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_SCP_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_SCP_KEY_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 198144833 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_STANDARD_ADDRESS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_STANDARD_ADDRESS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 193281307 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_STANDARD_CONSUMER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_STANDARD_CONSUMER_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 370008066 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQUIRY_STANDARD_PHONE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQUIRY_STANDARD_PHONE_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 118979083 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_APPLICANT_DETAILS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_APPLICANT_DETAILS_SEQUENCE"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 172111353 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_APP_ADDR_DETAILS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_APP_ADDR_DETAILS_SEQUENCE"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 212689187 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_APP_PHONE_DETAILS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_APP_PHONE_DETAILS_SEQUENCE"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 139168534 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_BATCH_DETAILS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_BATCH_DETAILS_SEQUENCE"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 18589315 CACHE 5000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_CONSUMER_DETAILS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_CONSUMER_DETAILS_SEQUENCE"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 121675 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_CP_ERROR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_CP_ERROR_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 2484367 CACHE 25 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_DETAILS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_DETAILS_SEQUENCE"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 172658807 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_MATCH_INVOL_P99_09_10_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_MATCH_INVOL_P99_09_10_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 25920541 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_MATCH_INVOL_P99_R02_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_MATCH_INVOL_P99_R02_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 882491365 CACHE 5000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_MATCH_INVOL_P99_R03_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_MATCH_INVOL_P99_R03_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 87349801 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_MATCH_INVOL_P99_R09_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_MATCH_INVOL_P99_R09_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 2092981 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_MATCH_INVOL_P99_R10_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_MATCH_INVOL_P99_R10_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 3237639 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_MATCH_INVOL_P99_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_MATCH_INVOL_P99_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 290096459 CACHE 5000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INQ_TRANS_DETAILS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INQ_TRANS_DETAILS_SEQUENCE"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 161032253 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INVOICE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."INVOICE_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 247488 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence IOI_STD_ADR_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."IOI_STD_ADR_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 123913051 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence IOI_STD_CNS_CNS_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."IOI_STD_CNS_CNS_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 117852352 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence IOI_STD_CNS_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."IOI_STD_CNS_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 29120907 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence IOI_STD_CNS_REL_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."IOI_STD_CNS_REL_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 164323581 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence IOI_STD_PHN_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."IOI_STD_PHN_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 60825157 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence IOT_BATCHID_RRIRTY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."IOT_BATCHID_RRIRTY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 10913 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_AGE_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_AGE_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 80224 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_BATCHID_RRIRTY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_BATCHID_RRIRTY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 11252 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_CACHE_BATCHID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_CACHE_BATCHID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 16823 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_COMP_DOB_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_COMP_DOB_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 527247 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_FULL_PHONE_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_FULL_PHONE_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 25762395 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_ID_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_ID_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 101366486 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_NAME_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_NAME_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 998359 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_PART_DOB_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_PART_DOB_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 106730 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_PHONE_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_PHONE_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 114969 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_REL_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_REL_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1717287 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_SCL_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_SCL_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8040094 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_SC_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_SC_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 424577 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LTC_SP_CLST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."LTC_SP_CLST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 448794 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence MATCH_INVOL_P0999_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."MATCH_INVOL_P0999_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 21003495 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence MIS_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."MIS_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 298506 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence MIS_JOB_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."MIS_JOB_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 122676 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_COMP_DOB_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_COMP_DOB_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 9586757 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_PHONE_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_PHONE_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8410341 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_PIN_AGE_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_PIN_AGE_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 14420718 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_PIN_PART_DOB_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_PIN_PART_DOB_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 14513200 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_PIN_REL_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_PIN_REL_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 140021460 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_SCL_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_SCL_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 36211049 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_SC_AGE_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_SC_AGE_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 943495 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_SC_PART_DOB_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_SC_PART_DOB_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1390373 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_SC_REL_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_SC_REL_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 9580107 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence NAME_SP_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."NAME_SP_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8127477 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLD_NEW_INQUIRY_BATCH_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."OLD_NEW_INQUIRY_BATCH_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 3987 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLM_EXTERNAL_TBL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."OLM_EXTERNAL_TBL_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999 INCREMENT BY 1 START WITH 2837 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence OLM_REQ_NBR_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."OLM_REQ_NBR_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 3375 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PA_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PA_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 223 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PHONE_AGE_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PHONE_AGE_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 800571 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PHONE_PART_DOB_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PHONE_PART_DOB_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 614108 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PIN_CD_REQ_ID_AUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PIN_CD_REQ_ID_AUD_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PIN_PART_DOB_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PIN_PART_DOB_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1205630 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PIN_PHONE_CLST_LTC_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PIN_PHONE_CLST_LTC_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1367063 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PRODUCT_ACCESS_AUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PRODUCT_ACCESS_AUD_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 74 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PRODUCT_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PRODUCT_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 4 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence PRODUCT_OPTION_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."PRODUCT_OPTION_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1331 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence P_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."P_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 37965 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REG_CUST_ID_AUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."REG_CUST_ID_AUD_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 56 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REG_CUST_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."REG_CUST_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 181 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REG_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."REG_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 31 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REISSUE_INQ_APPLICANT_DTLS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."REISSUE_INQ_APPLICANT_DTLS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 1945435 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REISSUE_INQ_APP_ADDR_DTLS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."REISSUE_INQ_APP_ADDR_DTLS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 2235009 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REISSUE_INQ_APP_PHONE_DTLS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."REISSUE_INQ_APP_PHONE_DTLS_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 1558386 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence REISSUE_INQ_SRCH_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."REISSUE_INQ_SRCH_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 81816281 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RESUME_RESTART_LOG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."RESUME_RESTART_LOG_SEQ"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 172008 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RL_AUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."RL_AUD_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RM_AUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."RM_AUD_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RM_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."RM_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 23 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RULE_GROUP_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."RULE_GROUP_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 46 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RULE_GROUP_INVOL_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."RULE_GROUP_INVOL_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1721 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RULE_MASTER_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."RULE_MASTER_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 335 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence R_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."R_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 25 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_ACTION_TRKG_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_ACTION_TRKG_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 52934 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_BATCH_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_BATCH_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 28420 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_BATCH_MASTER_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_BATCH_MASTER_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 28746 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_RAW_ADDRESS_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_RAW_ADDRESS_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 43736 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_RAW_INDV_ADDR_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_RAW_INDV_ADDR_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 16243 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_RAW_INDV_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_RAW_INDV_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 165337 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_RAW_INDV_PHONE_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_RAW_INDV_PHONE_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 16618 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_RAW_ORGN_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_RAW_ORGN_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 210888 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_RAW_ORGN_PHONE_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_RAW_ORGN_PHONE_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 223434 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_RAW_REQUEST_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_RAW_REQUEST_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 240648 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMM_REPORT_SUMMARY
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_COMM_REPORT_SUMMARY"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 7227575 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_HM_INQ_MAIL_LOG
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_HM_INQ_MAIL_LOG"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 345950 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_HM_LOGIN_HISTORY
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_HM_LOGIN_HISTORY"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 2413565 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_INQ_APP_ADDR_DETAILS_RAW
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_INQ_APP_ADDR_DETAILS_RAW"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 1105430 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_INQ_APP_DETAILS_RAW
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_INQ_APP_DETAILS_RAW"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 1170140 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_INQ_APP_PHONE_DETAILS_RAW
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_INQ_APP_PHONE_DETAILS_RAW"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 783856 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_INQ_DETAILS_RAW
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_INQ_DETAILS_RAW"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_INQ_ERR
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_INQ_ERR"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 3652745 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_LOG_TRKG_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_LOG_TRKG_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 24261 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_PORTFOLIO_TRACKING
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_PORTFOLIO_TRACKING"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 468634 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_REPORT_ID
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_REPORT_ID"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 173521015 CACHE 1000 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_REPORT_SUMMARY
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_REPORT_SUMMARY"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 167394987 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_REVIEW_TRACKING
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_REVIEW_TRACKING"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 757084 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SEQ_TEST
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SEQ_TEST"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 100 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SQ_HM_PG_DISCOUNT_MASTER
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SQ_HM_PG_DISCOUNT_MASTER"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1000000 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SQ_HM_PG_TRACKING
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SQ_HM_PG_TRACKING"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1611 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SQ_PG_RESPONSE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SQ_PG_RESPONSE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STD_CNS_DOB_CLST_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."STD_CNS_DOB_CLST_SEQUENCE"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 90366370 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STD_CNS_ID_CLST_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."STD_CNS_ID_CLST_SEQUENCE"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 263603680 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STD_CNS_NAME_CLST_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."STD_CNS_NAME_CLST_SEQUENCE"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 142951559 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STD_CNS_TOKEN_CLST_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."STD_CNS_TOKEN_CLST_SEQUENCE"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 20581057 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STD_QUEUE_MNGR_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."STD_QUEUE_MNGR_ID_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999 INCREMENT BY 1 START WITH 8391 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SUB_OPTION_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SUB_OPTION_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 10 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SUB_PRODUCT_KEY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."SUB_PRODUCT_KEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 101 CACHE 2 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TEMP_EXT_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."TEMP_EXT_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 7 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TEST_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."TEST_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 5 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TP_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."TP_ID_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1211 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TRL_PERIOD_AUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."TRL_PERIOD_AUD_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 78 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TRNS_CALC_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."TRNS_CALC_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 59876 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TRNS_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."TRNS_ID_SEQ"  MINVALUE 1 MAXVALUE 99999999999999999 INCREMENT BY 1 START WITH 324788 CACHE 500 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_REG_AUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."USER_REG_AUD_SEQ"  MINVALUE 0 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 2 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_TIME_SLICE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "HMCORE"."USER_TIME_SLICE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE ;
