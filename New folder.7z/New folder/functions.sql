--------------------------------------------------------
--  File created - Tuesday-July-11-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function DOLOGIC
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."DOLOGIC" (
   v_org_name   VARCHAR2
  ,v_meta_len   NUMBER
  ,v_this_idx   NUMBER
)
   RETURN VARCHAR2 IS

   this_idx    NUMBER        := v_this_idx;
   this_char   VARCHAR2 (1);
   hard        NUMBER;
   org_name    VARCHAR2 (10000) := v_org_name;
   meta_len    NUMBER        := v_meta_len;
BEGIN
   this_char := substr (org_name, this_idx, 1);

   IF this_char = 'B' THEN
      IF this_idx = meta_len THEN
         IF substr (org_name, this_idx - 1, 1) != 'M' THEN
            RETURN this_char;
         END IF;
      ELSE
         RETURN this_char;
      END IF;
   ELSIF this_char = 'C' THEN
      IF this_idx + 1 <= meta_len THEN
         IF      substr (org_name, this_idx - 1, 1) = 'S'
             AND substr (org_name, this_idx + 1, 1) IN ('E','I','Y') THEN
            RETURN '';
         END IF;
      END IF;

      IF this_idx + 2 <= meta_len THEN
         IF      substr (org_name, this_idx + 1, 1) = 'I'
             AND substr (org_name, this_idx + 2, 1) = 'A' THEN
            RETURN 'X';
         END IF;
      END IF;

      IF this_idx < meta_len THEN
         IF substr (org_name, this_idx + 1, 1) IN ('E','I','Y') THEN
            RETURN 'S';
         END IF;

         IF      substr (org_name, this_idx + 1, 1) = 'H'
             AND substr (org_name, this_idx - 1, 1) = 'S' THEN
            RETURN 'K';
         END IF;

         IF substr (org_name, this_idx + 1, 1) = 'H' THEN
            IF this_idx + 2 <= meta_len THEN
               IF substr (org_name, this_idx + 2, 1) IN ('A','E','I','O','U') THEN
                  RETURN 'K';
               ELSE
                  RETURN 'X';
               END IF;
            ELSE
               RETURN 'X';
            END IF;
         END IF;
      END IF;

      RETURN 'K';
   ELSIF this_char = 'D' THEN
      IF this_idx + 2 <= meta_len THEN
         IF      substr (org_name, this_idx + 1, 1) = 'G'
             AND substr (org_name, this_idx + 2, 1) IN ('E','I','Y') THEN
            RETURN 'J';
         END IF;
      END IF;

      RETURN 'T';
   ELSIF this_char = 'G' THEN
      IF this_idx + 2 <= meta_len THEN
         IF      substr (org_name, this_idx + 1, 1) = 'H'
             AND substr (org_name, this_idx + 2, 1) IN ('A','E','I','O','U','T') THEN
            RETURN '';
         END IF;
      END IF;

      IF this_idx + 1 = meta_len THEN
         IF substr (org_name, this_idx + 1, 1) = 'N' THEN
            RETURN '';
         END IF;
      END IF;

      IF this_idx + 3 = meta_len THEN
         IF      substr (org_name, this_idx + 1, 1) = 'N'
             AND substr (org_name, this_idx + 2, 1) = 'E'
             AND substr (org_name, this_idx + 3, 1) = 'D' THEN
            RETURN '';
         END IF;
      END IF;

      IF this_idx + 1 <= meta_len THEN
         IF      substr (org_name, this_idx - 1, 1) = 'D'
             AND substr (org_name, this_idx + 1, 1) IN ('E','I','Y') THEN
            RETURN '';
         END IF;
      END IF;

      IF this_idx < meta_len THEN
         IF substr (org_name, this_idx + 1, 1) IN ('E','I','Y') THEN
            RETURN 'J';
         END IF;
      END IF;

      RETURN 'K';
   ELSIF this_char = 'H' THEN
      IF this_idx = meta_len THEN
         RETURN '';
      END IF;

      IF substr (org_name, this_idx - 1, 1) IN ('C','S','P','T','G') THEN
         RETURN '';
      END IF;

      IF this_idx + 1 <= meta_len THEN
         IF substr (org_name, this_idx + 1, 1) IN ('A','E','I','O','U') THEN
            RETURN this_char;
         END IF;
      END IF;
   ELSIF this_char = 'K' THEN
      IF substr (org_name, this_idx - 1, 1) NOT BETWEEN '0' AND '9' THEN
         RETURN this_char;
      END IF;
   ELSIF this_char = 'P' THEN
      IF this_idx < meta_len THEN
         IF substr (org_name, this_idx + 1, 1) = 'H' THEN
            RETURN 'F';
         END IF;
      END IF;

      RETURN this_char;
   ELSIF this_char = 'Q' THEN
      RETURN 'K';
   ELSIF this_char = 'S' THEN
      IF this_idx + 2 <= meta_len THEN
         IF      substr (org_name, this_idx + 1, 1) = 'I'
             AND substr (org_name, this_idx + 2, 1) IN ('A','O') THEN
            RETURN 'X';
         END IF;
      END IF;

      IF this_idx < meta_len THEN
         IF substr (org_name, this_idx + 1, 1) = 'H' THEN
            RETURN 'X';
         END IF;
      END IF;

      RETURN this_char;
   ELSIF this_char = 'T' THEN
      IF this_idx + 2 <= meta_len THEN
         IF      substr (org_name, this_idx + 1, 1) = 'I'
             AND substr (org_name, this_idx + 2, 1) IN ('A','O') THEN
            RETURN 'X';
         END IF;

         IF      substr (org_name, this_idx + 1, 1) = 'C'
             AND substr (org_name, this_idx + 2, 1) = 'H' THEN
            RETURN '';
         END IF;
      END IF;

      IF this_idx < meta_len THEN
         IF substr (org_name, this_idx + 1, 1) = 'H' THEN
            IF substr (org_name, this_idx - 1, 1) = 'T' THEN
               RETURN '';
            ELSE
               RETURN 'O';
            END IF;
         END IF;
      END IF;

      RETURN this_char;
   ELSIF this_char IN ('W','Y') THEN
      IF this_idx < meta_len THEN
         IF substr (org_name, this_idx + 1, 1) IN ('A','E','I','O','U') THEN
            RETURN this_char;
         END IF;
      END IF;
   ELSIF      this_char BETWEEN 'A' AND 'Z'
          AND this_char NOT IN ('A','E','I','O','U') THEN
      RETURN this_char;
   END IF;

   RETURN '';
END; 

/
--------------------------------------------------------
--  DDL for Function FN_AVG_PMT_MISS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_AVG_PMT_MISS" (pn_curr_bal_history VARCHAR2, pn_last_months NUMBER DEFAULT NULL)
RETURN NUMBER
IS
    lv_cur_bal VARCHAR2(4000) := ','||pn_curr_bal_history||',';
    ln_avg NUMBER;
BEGIN

    IF pn_last_months IS NOT NULL
    THEN
        SELECT TRUNC(AVG(CUR_BAL), 2)
          INTO ln_avg
        FROM (
            SELECT lv_cur_bal, RW,
                   SUBSTR(lv_cur_bal, INSTR(lv_cur_bal,',',1, RW)+1, INSTR(lv_cur_bal, ',',1,RW+1) - INSTR(lv_cur_bal, ',',1,RW) - 1) CUR_BAL
              FROM DUAL,
                   (SELECT ROWNUM RW FROM DUAL CONNECT BY 1 = 1 AND ROWNUM <= 100)
            )
         WHERE ROWNUM <= pn_last_months;
    ELSE

        SELECT TRUNC(AVG(CUR_BAL), 2)
          INTO ln_avg
        FROM (
            SELECT lv_cur_bal, RW,
                   SUBSTR(lv_cur_bal, INSTR(lv_cur_bal,',',1, RW)+1, INSTR(lv_cur_bal, ',',1,RW+1) - INSTR(lv_cur_bal, ',',1,RW) - 1) CUR_BAL
              FROM DUAL,
                   (SELECT ROWNUM RW FROM DUAL CONNECT BY 1 = 1 AND ROWNUM <= 100)
            );
    
    END IF;
           
    RETURN NVL(TRUNC(ln_avg,2),0);

EXCEPTION
    WHEN OTHERS
    THEN
        RETURN 0;

END; 

/
--------------------------------------------------------
--  DDL for Function FN_DAYS_INTO_DHMS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_DAYS_INTO_DHMS" (p_days number) return varchar2 is
l_string varchar2 (50) ;
l_test number ;

begin

l_test := p_days ;
l_string := trunc(l_test) ||'days'|| ' ' ;

l_test := 24 * (l_test - trunc(l_test)) ;
l_string := l_string || trunc(l_test) ||'hrs '|| ': ' ;

l_test := 60 * (l_test - trunc(l_test)) ;
l_string := l_string || trunc(l_test) ||'min '|| ': ' ;

l_test := 60 * (l_test - trunc(l_test)) ;
l_string := l_string || round(l_test) ||'sec';

return l_string ;

end ; 

/
--------------------------------------------------------
--  DDL for Function FN_DAYS_INTO_DHMS_1
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_DAYS_INTO_DHMS_1" (p_days number) return varchar2 is
l_string varchar2 (50) ;
l_test number ;

begin

l_test := p_days ;
l_string := trunc(l_test) ||'days'|| ' ' ;

l_test := 24 * (l_test - trunc(l_test)) ;
l_string := l_string || trunc(l_test) ||'hrs '|| ': ' ;

l_test := 60 * (l_test - trunc(l_test)) ;
l_string := l_string || trunc(l_test) ||'min '|| ': ' ;

l_test := 60 * (l_test - trunc(l_test)) ;
l_string := l_string || round(l_test) ||'sec';

return l_string ;

end ; 

/
--------------------------------------------------------
--  DDL for Function FN_FIND_MISSING_SUBMISSION
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_FIND_MISSING_SUBMISSION" (
                                                              pv_schema varchar2,
                                                              pv_mfi varchar2,
                                                              pv_date_limit varchar2
                                                             )
return varchar2
as

lv_string varchar2(4000);

begin


--    SELECT LISTAGG(EXPECTED_ARRIVAL_DT,'','') WITHIN GROUP(ORDER BY TO_DATE(EXPECTED_ARRIVAL_DT,''MON-YY''))
--      into lv_string
--      FROM (
--            SELECT TO_CHAR(EXPECTED_ARRIVAL_DT,''MON-YY'') EXPECTED_ARRIVAL_DT
--              FROM HMCNSPROD.HM_DATA_TRKG_TBL_TEST
--             WHERE CONTRIBUTOR_ID = pv_mfi
--               AND TRIM(FILE_STATUS) NOT IN (''LOADED'',''REJECTED'',''ASSOCIATE'')
--               AND EXPECTED_ARRIVAL_DT IS NOT NULL
--               AND TO_CHAR(EXPECTED_ARRIVAL_DT,''MON-YY'') <> TO_CHAR(SYSDATE,''MON-YY'')  
--               AND EXPECTED_ARRIVAL_DT >= TO_DATE(pv_date_limit,''DDMMYYYY'')
--             GROUP BY TO_CHAR(EXPECTED_ARRIVAL_DT,''MON-YY'')
--             ORDER BY TO_DATE(TO_CHAR(EXPECTED_ARRIVAL_DT,''MON-YY''),''MON-YY'')
--           );

EXECUTE IMMEDIATE 
'
SELECT * FROM
   ( 
    SELECT TRIM(LISTAGG(EXPECTED_ARRIVAL_DT,'','') WITHIN GROUP(ORDER BY TO_DATE(EXPECTED_ARRIVAL_DT,''MON-YY''))) MISSING_CYCLE
     FROM(
     SELECT CASE 
            WHEN STR NOT LIKE ''%LOADED%''
            THEN EXPECTED_ARRIVAL_DT
            ELSE NULL
            END EXPECTED_ARRIVAL_DT
       FROM (      
             SELECT 
                    EXPECTED_ARRIVAL_DT,LISTAGG(FILE_STATUS,'','') WITHIN GROUP(ORDER BY EXPECTED_ARRIVAL_DT) STR
              FROM (
                    SELECT TO_CHAR(EXPECTED_ARRIVAL_DT,''MON-YY'') EXPECTED_ARRIVAL_DT,FILE_STATUS
                      FROM '||pv_schema||'.HM_DATA_TRKG_TBL
                     WHERE CONTRIBUTOR_ID = '''||pv_mfi||'''
                       AND EXPECTED_ARRIVAL_DT IS NOT NULL
                       AND TO_CHAR(EXPECTED_ARRIVAL_DT,''MON-YY'') <> TO_CHAR(SYSDATE,''MON-YY'')  
                       AND EXPECTED_ARRIVAL_DT >= TO_DATE('''||pv_date_limit||''',''DDMMYYYY'')
                     GROUP BY EXPECTED_ARRIVAL_DT,FILE_STATUS
                   )
              GROUP BY EXPECTED_ARRIVAL_DT
              )
              )
              ) WHERE MISSING_CYCLE IS NOT NULL ' INTO lv_string;            
    
    return NVL(lv_string,'No Missing Cycle'); 

exception
when no_data_found
then
     return NVL(lv_string,'No Missing Cycle');
when others
then
    return null;
end; 

/
--------------------------------------------------------
--  DDL for Function FN_METAPHONE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_METAPHONE" (
   v_pass_name   VARCHAR2
)
   RETURN VARCHAR2 IS

--===========================================================================
-- Copywright 2002, joel crainshaw and chet west
--===========================================================================
-- DESCRIPTION
--    PLSQL implementation of Lawrence Philips' Metaphone algorithm
--        METAPHONE function -- main function
--        DOLOGIC function -- called from METAPHONE    
--
--    The Metaphone Algorithm is an algorithm which returns the rough
--    approximation of how an English word sounds.
--    The author (Lawrence Philips) can be contacted at LFP at dolby.com
--    The original Metaphone algorithm appeared in the
--    December 1990 issue of Computer Language. 
--
--    This is an alternative to Oracle's built-in SOUNDEX.  Other advanced
--    versions of this algo. have been developed and metaphone is the basis
--    for some spell-checking programs
--===========================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   ---------- ------------------------------------------
-- joel        03/15/2002 Initial coversion into PLSQL
--                   
--===========================================================================
   meta_len    NUMBER;
   org_name    VARCHAR2 (10000);
   pass_name   VARCHAR2 (10000) := v_pass_name;
   new_char    NUMBER;
   ret_name    VARCHAR2 (10000);
BEGIN
   -- If no length, return
   IF pass_name IS NULL THEN
      RETURN 'NO INPUT Value';
   END IF;

   -- Initialization
   pass_name := upper (pass_name);
   org_name := '';

   -- Parse out unwanted's
   FOR idx IN 1 .. LENGTH (pass_name) LOOP
      IF    substr (pass_name, idx, 1) BETWEEN 'A' AND 'Z'
         OR substr (pass_name, idx, 1) BETWEEN '0' AND '9' THEN
         org_name := org_name || substr (pass_name, idx, 1);
      END IF;
   END LOOP;

   -- If no length, return
   IF org_name IS NULL THEN
      RETURN NULL;
   END IF;

   -- More initialization
   meta_len := LENGTH (org_name);
   ret_name := substr (org_name, 1, 1);

   -- Main loop to generate metaphone
   FOR idx IN 2 .. meta_len LOOP
      IF substr (org_name, idx, 1) NOT BETWEEN '0' AND '9' THEN
         ret_name := ret_name || DoLogic (org_name, meta_len, idx);
      END IF;
   END LOOP;

   RETURN ret_name;
END; 

/
--------------------------------------------------------
--  DDL for Function FN_PAYMENT_MISSED
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_PAYMENT_MISSED" (pn_dpd_history VARCHAR2, pn_payment_missed NUMBER, pn_pmt_flg NUMBER, pn_last_months NUMBER DEFAULT NULL)
RETURN NUMBER
IS
    lv_dpd VARCHAR2(4000) := pn_dpd_history;
    lv_tmp VARCHAR2(100);
    ln_cnt NUMBER := 0;
    ln_tot_months NUMBER;
    
BEGIN
    IF pn_last_months IS NULL
    THEN
        ln_tot_months := TRUNC(LENGTH(pn_dpd_history)/3);
    ELSE
        ln_tot_months := pn_last_months;
    END IF;
    
    IF pn_pmt_flg = 0
    THEN

        FOR i IN 0 .. (ln_tot_months - 1)
        LOOP
            lv_tmp := SUBSTR(lv_dpd, (i*3)+1, 3);
            
            IF TO_NUMBER(REGEXP_REPLACE(lv_tmp, '[^[:digit:]]')) > (30 * (pn_payment_missed - 1))
               AND TO_NUMBER(REGEXP_REPLACE(lv_tmp, '[^[:digit:]]')) <= (30 * (pn_payment_missed))
            THEN
                ln_cnt := ln_cnt + 1;
            END IF;
            
        END LOOP;

    ELSE

        FOR i IN 0 .. (ln_tot_months - 1)
        LOOP
            lv_tmp := SUBSTR(lv_dpd, (i*3)+1, 3);
            
            IF TO_NUMBER(REGEXP_REPLACE(lv_tmp, '[^[:digit:]]')) > (30 * (pn_payment_missed - 1))
            THEN
                ln_cnt := ln_cnt + 1;
            END IF;
            
        END LOOP;
    
    END IF;

    RETURN ln_cnt;

END; 

/
--------------------------------------------------------
--  DDL for Function FN_RATIO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_RATIO" (pn_num1 NUMBER, pn_num2 NUMBER)
RETURN VARCHAR2
IS
    ln_divider NUMBER;
    ln_dividend NUMBER;
    ln_mod NUMBER;    
    
BEGIN

    ln_divider := pn_num1;
    ln_dividend := pn_num2;
    
    WHILE ln_divider > 1
    LOOP
    
        ln_mod := MOD(ln_dividend, ln_divider);
        
        IF ln_mod = 0
        THEN
            EXIT;
        END IF;
        
        ln_dividend := ln_divider;
        ln_divider := ln_mod;
    
    END LOOP;
    
    RETURN TRUNC(pn_num1/ln_divider) || ':' || TRUNC(pn_num2/ln_divider);

EXCEPTION
    WHEN OTHERS
    THEN
        RETURN NULL;
END; 

/
--------------------------------------------------------
--  DDL for Function FN_TOTAL_DEL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."FN_TOTAL_DEL" (pn_dpd_history VARCHAR2, pn_last_months NUMBER)
RETURN NUMBER
IS
    lv_dpd VARCHAR2(4000) := pn_dpd_history;
    lv_tmp VARCHAR2(100);
    ln_cnt NUMBER := 0;
    
BEGIN
    FOR i IN 0 .. (pn_last_months - 1)
    LOOP
        lv_tmp := SUBSTR(lv_dpd, (i*3)+1, 3);
        
        IF TO_NUMBER(REGEXP_REPLACE(lv_tmp, '[^[:digit:]]')) > 0
        THEN
            ln_cnt := ln_cnt + 1;
        END IF;
        
    END LOOP;
    
    RETURN ln_cnt;
END;


--SELECT HMCORE.FN_TOTAL_DEL('020xxx000030', 5) FROM DUAL 

/
--------------------------------------------------------
--  DDL for Function F_LOB_REPLACE
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "HMCORE"."F_LOB_REPLACE" 
(   
    p_lob in clob,
    p_what in varchar2,
    p_with in varchar2 
) return clob 
as
    n number;
    l_result clob := p_lob;
begin

    n := dbms_lob.instr( p_lob, p_what);
    
    if (nvl(n,0) > 0) then
        dbms_lob.createtemporary(l_result, false, dbms_lob.call);
        dbms_lob.copy(l_result,
                      p_lob,
                      n - 1, 
                      1,
                      1 );
        dbms_lob.writeappend(l_result, length(p_with), p_with);
        dbms_lob.copy(l_result,
                      p_lob,
                      dbms_lob.getlength(p_lob) - (n + length(p_what)) + 1 ,
                      n + length(p_with),
                      n + length(p_what) );
    end if;

    if nvl(dbms_lob.instr(l_result, p_what), 0) > 0 then
        return f_lob_replace(l_result, p_what, p_with);
    end if;

    return l_result;

   end; 

/
